package base;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class ScreenBase {
	public WebDriver driver;
	
public ScreenBase(WebDriver driver) {
		
		this.driver= driver;
		
	}
	
	
}
