package screens;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import base.ScreenBase;

public class HomePage extends ScreenBase {
	
	@FindBy(xpath="//select[@id='departing']")
	public WebElement drpDeparting ;
	
	@FindBy(xpath="//select[@id='returning']")
	public WebElement drpReturning ;
	
	@FindBy(xpath="//input[@value='Search']")
	public WebElement search ;
	
	@FindBy(xpath="//div[@id='content']/p")
	public WebElement searchResult;
	
	@FindBy(id="promotional_code")
	public WebElement promotionCode;
	
	@FindBy(xpath="//p[@class='promo_code']")
	public WebElement promotionResult;
	
	@FindBy(xpath="//a[text()=' MarsAir']")
	public WebElement homeLogoText;
	
	@FindBy(xpath="//div//h2")
	public WebElement welcomeText;
	
	@FindBy(xpath="//div[@id='content']//h3")
	public WebElement bookingText;
	
	@FindBy(xpath="//a[text()=' Report an issue']")
	public WebElement bugReportLink;
	
	@FindBy(xpath="//a[text()=' Problem definition']")
	public WebElement problemDefinationLink;
	
	@FindBy(xpath="//a[text()='Privacy Policy']")
	public WebElement privacyPolicy;

	public HomePage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver,this);
		
		// TODO Auto-generated constructor stub
	}
	
	public void departing(String value) {
		
		//Locate Departing Dropdown and Select July				
			drpDeparting.click();
			Select Departing = new Select(drpDeparting);
			Departing.selectByValue(value);
	}
	
	public void returning(String value) {
		//Locate Returning Dropdown and Select December (next two Years)
			drpReturning.click();
			Select Returning = new Select(drpReturning);	
			Returning.selectByValue(value);	
			//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	public String search() {
		search.click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		String SearchResult = searchResult.getText();
		return SearchResult;

	}

	public void inputPromotionCode(String promocode) {
		promotionCode.sendKeys(promocode);
	}
	
	public String validatePromotionCodeText() {
		String PromotionApplied = promotionResult.getText();
		return PromotionApplied; 
	}
	
	public Boolean ClicklogoText() {

		if (homeLogoText.isEnabled() && homeLogoText.getTagName().equalsIgnoreCase("a")) {
                System.out.println("Element is clickable and behaves like a link.");
			homeLogoText.click();
		Boolean welcomeTextDisplayed = welcomeText.isDisplayed();
		return welcomeTextDisplayed;
			}
		else  {
			System.out.println("Element is not clickable and not a link.");
			return false;
		}
	}
	
	public Boolean ClickbookingText() {
		
		if (bookingText.isEnabled() && bookingText.getTagName().equalsIgnoreCase("a")) {
			bookingText.click();
		Boolean welcomeTextDisplayed = welcomeText.isDisplayed();
		return welcomeTextDisplayed;
		}
		else {
			System.out.println("Element is not clickable and not a link.");
			return false;
		}
		
	}
	
	public void accessWebsite() {
			homeLogoText.isDisplayed();
			welcomeText.isDisplayed();
			bookingText.isDisplayed();
			drpDeparting.isDisplayed();
			drpReturning.isDisplayed();
			promotionCode.isDisplayed();
			search.isDisplayed();
			bugReportLink.click();
			homeLogoText.click();
			problemDefinationLink.click();
			homeLogoText.click();
			privacyPolicy.click();
	}
	
}
