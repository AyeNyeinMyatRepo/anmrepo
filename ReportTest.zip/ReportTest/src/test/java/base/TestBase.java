package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

public class TestBase {
	public WebDriver driver;

	@Parameters({"browser", "URL"})

	@BeforeMethod
		public void setUp(String browser, String URL) {
		
		if(browser.equals("chrome")) {
			driver = new ChromeDriver();
			
		}
		else if(browser.equals("firefox")) {
			driver = new FirefoxDriver();
		}
		else if(browser.equals("safari")) {
			driver = new SafariDriver();
		}
		
		
		//driver = new SafariDriver();
		//driver = new ChromeDriver();
		
		//driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get(URL);
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		}
	
		public String takeScreenshot() {
    	Date d = new Date();
		String fileName = d.toString().replace(":","").replace(" ","")+".jpg";
		File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		
		try {
			FileUtils.copyFile(srcFile,new File(System.getProperty("user.dir")+"/reports/"+fileName));
			System.out.println(fileName);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace(); 
		} 
		return fileName;
		
		}
	
	@AfterMethod
		public void quit() {
		driver.close();
	}
}
