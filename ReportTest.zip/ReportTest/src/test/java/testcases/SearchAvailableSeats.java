package testcases;

import org.testng.annotations.Test;
import org.junit.Assert;


import base.TestBase;
import screens.HomePage;

public class SearchAvailableSeats extends TestBase{
	HomePage homePage;
	
	@Test
	
	//Available Seats Found
	
	public void checkAvailableSeats() {
		homePage = new HomePage(driver);
		homePage.departing("0");
		homePage.returning("5");
		//homePage.search();
		String validationMessage = homePage.search();
		Assert.assertTrue(validationMessage.contains("Seats available!")); 
		System.out.println("Available Seats Found.");
	}
	
	
	@Test
	
	//No Available Seats
	
	public void checkNoAvailableSeats() {
		homePage = new HomePage(driver);
		homePage.departing("1");
		homePage.returning("4");
		//homePage.search();
		String validationMessage = homePage.search();
		Assert.assertTrue(validationMessage.contains("Sorry, there are no more seats available.")); 
		//Assert.fail("Intentionally Failling the test");
		System.out.println("There are no available seats.");

	}
	
	@Test
	
	//Search Without Selecting Departure
	
	public void searchWithoutDeparting() {
			homePage = new HomePage(driver);
			homePage.returning("4");
			//homePage.search();
			String validationMessage = homePage.search();
			Assert.assertTrue(validationMessage.contains("Please select preferred Departure Time")); 
			//Assert.fail("Intentionally Failling the test");
			
			System.out.println("Please select Departure");

	}
	
	@Test
	//Search Without Selecting Return
	
		public void searchWithoutReturn() {
			homePage = new HomePage(driver);
			homePage.departing("3");
			//homePage.search();
			String validationMessage = homePage.search();
			Assert.assertTrue(validationMessage.contains("Please select preferred Return Time")); 
			//Assert.fail("Intentionally Failling the test");
			System.out.println("Please select Return");

		}

}
