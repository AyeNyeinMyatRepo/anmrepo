package testcases;

import org.testng.annotations.Test;
import org.junit.Assert;


import base.TestBase;
import screens.HomePage;

public class ValidateReturnDate extends TestBase{
	HomePage homePage;
	
	@Test
	
	//Validate Return Date which is less than 1 year from Departure
	
	public void returnDateLessThan1Year() {
		homePage = new HomePage(driver);
		homePage.departing("0");
		homePage.returning("1");
		//homePage.search();
		String validationMessage = homePage.search();
		Assert.assertTrue(validationMessage.contains("Unfortunately, this schedule is not possible. Please try again.")); 
		System.out.println("Return Date cannot be less than 1 year from Departure Date");
	}
	
	@Test
	
	//Validate Return Date which is same as Departure
	
	public void returnDateSameasDeparture() {
		homePage = new HomePage(driver);
		homePage.departing("1");
		homePage.returning("1");
		//homePage.search();
		String validationMessage = homePage.search();
		Assert.assertTrue(validationMessage.contains("Unfortunately, this schedule is not possible. Please try again.")); 
		System.out.println("Return Date cannot be same as Departure Date");
	}
	
	@Test
	
	//Validate Return Date which is past from Departure
	
	public void pastReturnDate() {
		homePage = new HomePage(driver);
		homePage.departing("2");
		homePage.returning("0");
		//homePage.search();
		String validationMessage = homePage.search();
		Assert.assertTrue(validationMessage.contains("Unfortunately, this schedule is not possible. Please try again.")); 
		System.out.println("Return Date cannot be past date from Departure Date");
	}

}
