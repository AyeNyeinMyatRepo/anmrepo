package testcases;

import org.testng.annotations.Test;
import org.junit.Assert;


import base.TestBase;
import screens.HomePage;

public class LinkToHomePage extends TestBase{
	HomePage homePage;
	
	@Test
	
	//Validate Logo Text is clickable and Home Page is redirected upon clicking
	
	public void clickLogoText() {
		homePage = new HomePage(driver);
		//Boolean redirectHome = homePage.ClicklogoText();
		Assert.assertTrue(homePage.ClicklogoText());
		System.out.println("Home Page can be access via Logo Text");
	}
	
	
	@Test
	
	//Validate Booking Text is clickable and Home Page is redirected upon clicking

	public void clickBookingText() {
		homePage = new HomePage(driver);
		Boolean redirectHome = homePage.ClickbookingText();
		Assert.assertTrue(redirectHome);
		//omePage.
		System.out.println("Home Page can be access via Booking Text");
	}
}
