package testcases;

import org.testng.annotations.Test;
import org.junit.Assert;


import base.TestBase;
import screens.HomePage;

public class AccessWebsite extends TestBase{
	HomePage homePage;
	
	@Test
	
	//Website can be accessed
	// Booling Form is displayed
	//Links can be clickable.
	public void accessMarsAirWebsite() {
		homePage = new HomePage(driver);
		homePage.accessWebsite();
		System.out.println("Website can be accessed. Booking Form is displayed. Links are clickable.");
	}

}
