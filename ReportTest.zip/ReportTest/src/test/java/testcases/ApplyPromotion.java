package testcases;
import org.testng.annotations.Test;
import org.junit.Assert;


import base.TestBase;
import screens.HomePage;


public class ApplyPromotion extends TestBase{
	HomePage homePage;
	
	@Test
	
	//Apply First Valid Promotion Code
	
	public void applyValidPromoCode() {
		homePage = new HomePage(driver);
		homePage.departing("0");
		homePage.returning("5");
		homePage.inputPromotionCode("AF3-FJK-418");
		homePage.search();
		String validationMessage = homePage.validatePromotionCodeText();
		Assert.assertTrue(validationMessage.contains("Promotional code AF3-FJK-418 used: 30% discount!")); 
		System.out.println("Promotion is valid and applied");
	}
	
	
	@Test
	
	//Apply Second Valid Promotion Code
	
		public void applySecondValidPromoCode() {
			homePage = new HomePage(driver);
			homePage.departing("0");
			homePage.returning("5");
			homePage.inputPromotionCode("JJ5-OPQ-320");
			homePage.search();
			String validationMessage = homePage.validatePromotionCodeText();
			Assert.assertTrue(validationMessage.contains("Promotional code JJ5-OPQ-320 used: 50% discount!")); 
			System.out.println("Promotion is valid and applied");
		}
	
	@Test
	
	//Apply Promo Code with Incorrect Last Digit
		public void applyInvalidPromoCode() {
			homePage = new HomePage(driver);
			homePage.departing("0");
			homePage.returning("5");
			homePage.inputPromotionCode("JJ5-OPQ-322");
			homePage.search();
			String validationMessage = homePage.validatePromotionCodeText();
			Assert.assertTrue(validationMessage.contains("Sorry, code JJ5-OPQ-322 is not valid")); 
			System.out.println("Promotion code is invalid");
		}
	
	
	@Test
	//Apply Promo Code with Incorrect format
			public void applyInvalidPromoCodeFormat() {
				homePage = new HomePage(driver);
				homePage.departing("0");
				homePage.returning("5");
				homePage.inputPromotionCode("abc");
				homePage.search();
				String validationMessage = homePage.validatePromotionCodeText();
				Assert.assertTrue(validationMessage.contains("Sorry, code abc is not valid")); 
				System.out.println("Promotion code is invalid");
			}
	
}

